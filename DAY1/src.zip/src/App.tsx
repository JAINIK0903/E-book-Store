import './App.css';
import { Greet } from './compo/greet';
import { Person } from './compo/person';
import { Personlist } from './compo/personlist';
import { Status } from './compo/status';
import { Heading } from './compo/heading';
import{ Oscar } from './compo/oscar';
import { Button } from'./compo/button';
import{ Input } from './compo/input';
import{ Container } from './compo/container';
import { Randomnumber } from './compo/restriction/randomnumber';
import { Toast } from './compo/templatelitrals/toast';
function App() {
  const personName={
    first:'Bruce',
    last:'Wayne',
  }
  const namelist=[
    {
      first:'Bruce',
      last:'Wayne',
    },
    {
      first:'Clark',
      last:'Kent',
    },
    {
      first:'Princess',
      last:'Diana',
    },
    
  ]
  return (
    <div className='App'>
      <Greet  name='op' messageCount={10} isloggedin={false} />
      <Person name={personName}/>
      <Personlist name={namelist}/>
      <Status status='error'/>
     <Heading>Placeholder text
     </Heading>
     <Oscar>
        <Heading>oscar goes to jhonny deep</Heading>
     </Oscar>
     <Button handleclick={(event, id)=>{
      console.log('button clicked',event,id)
     }}
     />
     <Toast position='center'/>
     <Input value="" handlechange={(event)=>console.log(event)}/>
     <Container styles={{border: '10px solid blue',padding:'1rem'}}/>
     <Randomnumber value={10} isPositive />
    </div>
  );
}

export default App;


