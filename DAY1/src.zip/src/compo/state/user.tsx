import { useState } from "react";
 

type authuser={
    name:string
    email:string
}

export const User =()=> {
    const [user,setuser]=useState<authuser | null>(null)
    const handlelogin=()=>{
        setuser({
            name:'Jainik',
            email:'Jainik@gmail.com',
        })
    }
    const handlelogout=()=>{
        setuser(null)
    }
    return (
        <div>
            <button onClick={handlelogin}>LOGIN</button>
            <button onClick={handlelogout}>LOGOUT</button>
            <div>User name is{user?.name}</div>
            <div>user email is{user?.email}</div>
        </div>
    )
}