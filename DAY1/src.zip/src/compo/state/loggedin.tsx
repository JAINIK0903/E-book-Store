import { useState } from "react";

export const Loggedin=()=> {
    const [isloggedin,setisloggedin]=useState(false)
    const handlelogin=()=>{
        setisloggedin(true)
    }
    const handlelogout=()=>{
     setisloggedin(false)   
    }
    return(
        <div>
            <button onClick={handlelogin}>LOGIN</button>
            <button onClick={handlelogout}>LOGOUT</button>
            <div>User is {isloggedin ? 'logged in' : 'logged out'}</div>
        </div>
    )
}
