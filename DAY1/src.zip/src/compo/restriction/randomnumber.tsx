type RandomnumberType={
    value: number
}

type PositiveNumber=RandomnumberType&{
    isPositive:boolean
    isNegative?:never
    isZero?:never
}
type NegativeNumber=RandomnumberType&{
    isPositive:boolean
    isNegative?:never
    isZero?:never
}
type Zero=RandomnumberType&{
    isPositive:boolean
    isNegative?:never
    isZero?:never
}




type randomnumberprops = PositiveNumber | NegativeNumber | Zero

export const Randomnumber = ({
    value,
    isPositive,
    isNegative,
    isZero,
}:randomnumberprops)=>{
    return(
        <div>
            {value}{isPositive && 'positive'} {isNegative && 'negative'}{''}
            {isZero && 'zero'}
        </div>

    )
}