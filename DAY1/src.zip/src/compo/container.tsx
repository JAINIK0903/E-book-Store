type containerprops={
    styles:React.CSSProperties
}

export const Container=(props: containerprops)=>{
    return <div style={props.styles}>100 kills by Godlin</div>
}